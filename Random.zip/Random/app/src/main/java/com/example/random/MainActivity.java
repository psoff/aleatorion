package com.example.random;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView resultado;
    private EditText entrada;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultado = (TextView) findViewById(R.id.resultado);
        entrada = (EditText) findViewById(R.id.entrada);

        btn = (Button) findViewById(R.id.btn);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        if(btn == view){
            aceptar();
        }
    }

    private void aceptar() {

        int numero = Integer.valueOf(entrada.getText().toString());

        for (int i= 1; i <= numero; i++ ){
            int random =(int)(Math.random()*(numero));
            String r = String.valueOf(random);
            resultado.setText(r);
        }
    }
}